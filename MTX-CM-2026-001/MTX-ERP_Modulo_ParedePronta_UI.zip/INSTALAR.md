# Módulo Parede-Pronta R5 — instalação no montex-erp-v5

## 1. Dependência
```bash
npm i html5-qrcode
```

## 2. Arquivos
Copiar a pasta `src/modules/paredePronta/` para o repo (3 arquivos):
- `useParedePronta.js` — toda a lógica Supabase (kanban, máquina de estados do bipe, kits, ocorrências, realtime)
- `ScannerQR.jsx` — câmera (getUserMedia — funciona no Capacitor/iOS) + fallback de digitação
- `ParedePronta.jsx` — tela (kanban W1..W6, kits, painel piloto, modal de confirmação)

## 3. Ajustar 1 import
Em `useParedePronta.js`, linha 5: apontar para o client Supabase do ERP
(ex.: `../../lib/supabase` ou `../../supabaseClient`).

## 4. Rota
```jsx
import ParedePronta from "./modules/paredePronta/ParedePronta";
// <Route path="/parede-pronta" element={<ParedePronta/>} />
```

## 5. Realtime (1 clique no painel Supabase)
Database → Replication → habilitar a tabela `pp_paredes` na publicação
`supabase_realtime` (para o kanban atualizar entre celulares).

## Como funciona o bipe (máquina de estados)
| Estado da parede | Bipe faz | Grava |
|---|---|---|
| FILA | Iniciar W1 | inicio_estacao W1 |
| Wn (início aberto) | Concluir Wn | fim_estacao Wn |
| Wn (concluída, n<6) | Iniciar Wn+1 | inicio_estacao Wn+1 |
| W6 concluída | Carga na carreta | carga → EXPEDIDA |
| EXPEDIDA | Descarga no site | descarga → RECEBIDA |
| RECEBIDA | Instalada | fim_passo (ordem) → INSTALADA |

Kits: 1º bipe = expedição ✓ · 2º bipe = recebimento ✓.
Botões NC / RETOQUE / CONTADOR no modal alimentam o piloto sem sair da tela.
O painel PILOTO lê `pp_v_takt` — os minutos aparecem sozinhos a partir dos pares de bipes.

## QRs para imprimir
Os códigos já estão no banco (`pp_paredes.qr_code`, `pp_kits.qr_code`, `pp_casas.qr_code`
— padrão `MTX-C0001-F1`). Qualquer gerador de QR em lote serve; sugestão de etiqueta:
QR 50×50 mm + código humano-legível embaixo, vinil, na borda superior direita da parede
(zona da banda seca — não cobre acabamento).
